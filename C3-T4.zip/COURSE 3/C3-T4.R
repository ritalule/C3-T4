library(tidyverse)
library(readxl)
library(knitr)
library(ggplot2)
library(lubridate)
library(arules)
library(arulesViz)
library(plyr)
library(dplyr)

install.packages("TSP")
install.packages("dendextend")
install.packages("DEoptimR")
install.packages("plotly")

??arules
??arulesViz


ElectronidexTransactions2017 <- read.transactions("~/Project 2/COURSE 3/ElectronidexTransactions2017.csv", format = 'basket')
View(ElectronidexTransactions2017)
summary(ElectronidexTransactions2017)
image(ElectronidexTransactions2017, topN = 20)
image(sample(ElectronidexTransactions2017, 500))

inspect (ElectronidexTransactions2017) # You can view the transactions. Is there a way to see a certain # of transactions?
length (ElectronidexTransactions2017) # Number of transactions.
size (ElectronidexTransactions2017) # Number of items per transaction
LIST(ElectronidexTransactions2017) # Lists the transactions by conversion (LIST must be capitalized)
itemLabels(ElectronidexTransactions2017)# To see the item labels

itemFrequencyPlot(ElectronidexTransactions2017, topN = 20)
image(ElectronidexTransactions2017, topN = 5)
image(sample(ElectronidexTransactions2017, 500))



image(sample(ElectronidexTransactions2017, 13))

Rule1<- apriori (ElectronidexTransactions2017, parameter = list(supp = 0.1, conf = 0.8))
inspect(Rule1)
Rule1<- sort(Rule1, by = "confidence", decreasing = TRUE)

summary(Rule1)

save.image()

inspect(Rule1)

is.redundant(Rule1, measure = "confidence")
is.redundant(Rule1, measure = "support")
is.redundant(Rule1, measure = "lift")
is.redundant(Rule1)

inspect(sort( ElectronidexTransactions2017, by = "confidence"))

inspect(sort(ElectronidexTransactions2017[1:10], by = "support"))

is.na(ElectronidexTransactions2017)

DesktopRules <- subset(Rule1, items %in% "Desktop")
DesktopRules

save.image()

inspect(DesktopRules)

is.redundant(Rule1)

plot(Rule1[1:10], method="graph", control=list(type="items"))
top10 <- Rule1[1:10]

plot(top10)

plot(top10, method = "graph")

plot(top10, method = "grouped")

## S3 method for class 'rules' - this is the code for plotting
plot(top10, method = NULL, measure = "support", shading = "lift", 
     interactive = NULL, engine = "default", data = NULL, control = NULL)

inspect(sort(Rule1[1:13], by = "lift"))

Rule1_redundant <- is.redundant(Rule1)

Rule1_redundant

dev.off()


